CREATE VIEW alumno AS
  SELECT
    concat(`p`.`Apellidos`, ', ', `p`.`Nombre`) AS `nombre`,
    `p`.`NIF`                                   AS `NIF`,
    `p`.`Curso`                                 AS `Curso`
  FROM (`pagina2018b`.`persona` `p`
    JOIN `pagina2018b`.`alumno` `a`)
  WHERE (`p`.`NIF` = `a`.`NIF`);
