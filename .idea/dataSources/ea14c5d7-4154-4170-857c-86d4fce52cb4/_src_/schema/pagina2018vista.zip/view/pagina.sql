CREATE VIEW pagina AS
  SELECT
    `p`.`Titulo`              AS `titulo`,
    `e`.`NombreFicheroEstilo` AS `estilo`,
    `e`.`RutaFicheroEstilo`   AS `ruta`,
    `pe`.`OrdenEstilo`        AS `ordenEstilo`,
    `m`.`ValorMetaData`       AS `meta`,
    `p`.`CodigoPagina`        AS `CodigoPagina`,
    `p`.`NombrePagina`        AS `NombrePagina`
  FROM ((((`pagina2018b`.`pagina_estilo` `pe`
    JOIN `pagina2018b`.`pagina` `p`) JOIN `pagina2018b`.`estilo` `e`) JOIN `pagina2018b`.`metadata` `m`) JOIN
    `pagina2018b`.`pagina_meta` `pm`)
  WHERE ((`pe`.`CodigoEstilo` = `e`.`CodigoEstilo`) AND (`pe`.`CodigoPagina` = `p`.`CodigoPagina`) AND
         (`p`.`CodigoPagina` = `pm`.`CodigoPagina`) AND (`m`.`CodigoMetaData` = `pm`.`CodigoMetaData`));
