CREATE VIEW js AS
  SELECT DISTINCT
    `w`.`NombrePagina`    AS `pagina`,
    `j`.`NombreFicheroJs` AS `js`,
    `j`.`RutaFicheroJs`   AS `ruta`,
    `p`.`OrdenJs`         AS `orden`
  FROM `pagina2018b`.`javascript` `j`
    JOIN `pagina2018b`.`pagina_js` `p`
    JOIN `pagina2018b`.`pagina` `w`
  WHERE ((`p`.`CodigoJs` = `j`.`CodigoJs`) AND (`p`.`CodigoPagina` = `w`.`CodigoPagina`))
  ORDER BY `p`.`OrdenJs`;
