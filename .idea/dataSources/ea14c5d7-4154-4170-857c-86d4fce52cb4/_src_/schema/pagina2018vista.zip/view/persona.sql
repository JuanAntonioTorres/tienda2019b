CREATE VIEW persona AS
  SELECT
    `p`.`NIF`             AS `NIF`,
    `p`.`Apellidos`       AS `Apellidos`,
    `p`.`Nombre`          AS `Nombre`,
    `p`.`CodigoPostal`    AS `CodigoPostal`,
    `p`.`Domicilio`       AS `Domicilio`,
    `p`.`FechaNacimiento` AS `FechaNacimiento`,
    `p`.`TelefonoFijo`    AS `TelefonoFijo`,
    `p`.`TelefonoMovil`   AS `TelefonoMovil`,
    `p`.`Email`           AS `Email`,
    `p`.`imagen`          AS `imagen`
  FROM `pagina2018b`.`persona` `p`;
