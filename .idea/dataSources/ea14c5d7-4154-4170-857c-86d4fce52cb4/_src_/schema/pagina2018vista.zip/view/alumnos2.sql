CREATE VIEW alumnos2 AS
  SELECT concat(`p`.`Apellidos`, ', ', `p`.`Nombre`) AS `nombre`
  FROM `pagina2018b`.`persona` `p`
    JOIN `pagina2018b`.`alumno` `a`
  WHERE ((`p`.`NIF` = `a`.`NIF`) AND (`a`.`CodigoCurso` = 2))
  ORDER BY 1;
