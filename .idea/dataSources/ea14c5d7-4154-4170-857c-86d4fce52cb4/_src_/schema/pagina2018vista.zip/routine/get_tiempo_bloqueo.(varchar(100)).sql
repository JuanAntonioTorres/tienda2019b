CREATE PROCEDURE get_tiempo_bloqueo(IN email VARCHAR(100), OUT tiempo DATETIME)
  BEGIN

DECLARE tiempoB DATETIME DEFAULT null;

SELECT `TiempoBloqueo` INTO tiempoB FROM pagina2018b.`usuario`
WHERE `EmailUsuario` = email and `BloqueadoUsuario`= true; 

IF tiempoB THEN SET tiempo = tiempoB;
END IF;
END;
