CREATE PROCEDURE check_usuario(IN email2 VARCHAR(100), IN contrasena2 VARCHAR(100), OUT estado2 INT)
  BEGIN
 
CALL pagina2018b.check_usuario(email2,contrasena2,estado2);

END;
