CREATE PROCEDURE is_email(IN email VARCHAR(100), OUT mensaje TINYINT(1))
  BEGIN
DECLARE miEmail varchar(100) DEFAULT null;
SELECT `EmailUsuario` INTO miEmail FROM pagina2018b.`usuario` 
WHERE `EmailUsuario` = email;
IF miEmail is null THEN SET mensaje = "0";
  ELSE SET mensaje = "1";
END IF;
END;
