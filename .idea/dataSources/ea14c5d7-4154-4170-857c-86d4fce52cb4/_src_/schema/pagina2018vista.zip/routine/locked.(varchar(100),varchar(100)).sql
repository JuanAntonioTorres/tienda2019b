CREATE PROCEDURE locked(OUT mensaje TINYINT(1), IN email VARCHAR(100), IN clave VARCHAR(100))
  BEGIN

UPDATE pagina2018b.`usuario` 
	SET `BloqueadoUsuario`= 1 ,`TiempoBloqueo`= now() ,ClaveBloqueo = clave WHERE `EmailUsuario`= email;
IF ROW_COUNT() THEN SET mensaje = "1"; 
	ELSE SET mensaje = "0"; 
END IF;
END;
