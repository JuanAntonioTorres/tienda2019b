CREATE PROCEDURE is_locked(IN email VARCHAR(100), OUT mensaje TINYINT(1))
  BEGIN
DECLARE bloqueo int DEFAULT 0;
Select  `BloqueadoUsuario` INTO bloqueo
FROM pagina2018b.`usuario` 
WHERE EmailUsuario = email	and `BloqueadoUsuario`= 1;
IF bloqueo = 1 THEN SET mensaje = "1"; 
	ELSE SET mensaje = "0"; 
END IF;
END;
