CREATE PROCEDURE get_claveBloqueo(IN email VARCHAR(100), OUT clave VARCHAR(100))
  BEGIN

DECLARE miclave varchar(50) DEFAULT null;

SELECT 	ClaveBloqueo  INTO miclave FROM pagina2018b.`usuario`
WHERE `EmailUsuario` = email and `BloqueadoUsuario`= true; 

IF miclave THEN SET clave = miclave;
END IF;
END;
