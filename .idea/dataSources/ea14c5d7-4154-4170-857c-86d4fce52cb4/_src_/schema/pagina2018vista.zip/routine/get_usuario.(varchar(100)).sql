CREATE PROCEDURE get_usuario(IN email VARCHAR(100))
  BEGIN

DELETE from vpersona;
 INSERT INTO `vpersona`(`NIF`, `Apellidos`, `Nombre`, `CodigoPostal`, `Domicilio`, `FechaNacimiento`, `TelefonoFijo`, `TelefonoMovil`, `Email`, `imagen`) SELECT p.* from pagina2018b.persona p where p.email = email;

END;
