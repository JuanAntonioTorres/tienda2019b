CREATE PROCEDURE is_email_familia(IN email VARCHAR(200), OUT mensaje TINYINT(1))
  BEGIN
DECLARE miEmail varchar(100) DEFAULT null;

SELECT p.`Email` INTO miEmail FROM pagina2018b.`persona` p, pagina2018b.familia f  WHERE  p.`NIF` = f.`NIFFamilia` AND p.`Email` = email; 

IF miEmail is null THEN SET mensaje = false;
  ELSE SET mensaje = true;
END IF;
END;
