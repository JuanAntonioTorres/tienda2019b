CREATE PROCEDURE get_arbol(OUT body2 VARCHAR(2000), IN pagina2 INT)
  BEGIN
 
CALL pagina2018b.get_arbol(body2,pagina2);

END;
