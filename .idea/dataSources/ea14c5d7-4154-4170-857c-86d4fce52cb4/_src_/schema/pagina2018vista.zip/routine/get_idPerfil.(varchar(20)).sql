CREATE PROCEDURE get_idPerfil(IN tipoPerfil VARCHAR(20), OUT mensa INT)
  BEGIN

DECLARE idPerfil int DEFAULT 0;

SELECT `IdPerfilUsuario` INTO idPerfil FROM pagina2018b.`perfil_usuario` WHERE `PerfilUsuario` = tipoPerfil;

SET mensa = idPerfil;
END;
