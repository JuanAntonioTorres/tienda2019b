CREATE PROCEDURE is_email_alumno(IN email VARCHAR(100), OUT mensaje TINYINT(1))
  BEGIN
DECLARE miEmail varchar(100) DEFAULT null;

SELECT `Email` INTO miEmail FROM pagina2018b.`persona` p, pagina2018b.alumno a  WHERE  p.`NIF` = a.`NIF` AND p.`Email` = email; 

IF miEmail is null THEN SET mensaje = false;
  ELSE SET mensaje = true;
END IF;
END;
