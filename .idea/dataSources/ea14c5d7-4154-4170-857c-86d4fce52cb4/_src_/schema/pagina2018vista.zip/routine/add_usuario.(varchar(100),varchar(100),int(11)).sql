CREATE PROCEDURE add_usuario(IN email VARCHAR(100), IN password VARCHAR(100), IN idPerfil INT, OUT mensa TINYINT(1))
  BEGIN
INSERT INTO pagina2018b.`usuario`(`EmailUsuario`, `PasswordUsuario`, `IdPerfilUsuario`) VALUES (email,MD5(password),idPerfil);

IF ROW_COUNT() > 0 THEN SET mensa = true;
   ELSE SET mensa =  false;
END IF;
END;
