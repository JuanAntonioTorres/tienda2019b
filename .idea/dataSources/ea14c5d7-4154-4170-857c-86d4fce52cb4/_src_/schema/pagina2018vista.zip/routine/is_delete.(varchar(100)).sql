CREATE PROCEDURE is_delete(IN email VARCHAR(100), OUT mensaje TINYINT(1))
  BEGIN
DECLARE borrado int DEFAULT 0;
SELECT `BorradoUsuario` INTO borrado FROM pagina2018b.`usuario` 
WHERE `EmailUsuario` = email and `BorradoUsuario` = 1;
IF borrado = 1 THEN SET mensaje = true; 
	ELSE SET mensaje = false; 
END IF;
END;
