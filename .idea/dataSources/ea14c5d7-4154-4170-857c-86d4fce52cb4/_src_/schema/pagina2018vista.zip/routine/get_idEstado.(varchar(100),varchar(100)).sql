CREATE PROCEDURE get_idEstado(IN email VARCHAR(100), IN pass VARCHAR(100), OUT estado VARCHAR(30))
  BEGIN

DECLARE perfil varchar(30) DEFAULT "";
SELECT p.EstadoUsuario INTO estado
FROM pagina2018b.`usuario` u, pagina2018b.perfil_usuario p
WHERE u.`IdPerfilUsuario` = p.IdPerfilUsuario
AND `EmailUsuario` = email AND  u.`PasswordUsuario` = MD5(pass);
END;
