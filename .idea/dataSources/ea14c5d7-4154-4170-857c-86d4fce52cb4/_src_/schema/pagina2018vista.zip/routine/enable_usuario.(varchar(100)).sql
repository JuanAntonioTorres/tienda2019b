CREATE PROCEDURE enable_usuario(IN email VARCHAR(100), OUT mensaje TINYINT(1))
  BEGIN

UPDATE pagina2018b.`usuario` SET `BorradoUsuario`= 0
WHERE `EmailUsuario` = email and BorradoUsuario = 1;
IF ROW_COUNT() > 0 THEN SET mensaje = true;
  ELSE SET mensaje = false;
END IF;


END;
